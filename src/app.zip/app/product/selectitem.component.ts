import { Component, Input, SimpleChanges } from "@angular/core";
import { Item } from '../ilist.module';

@Component({
    selector:"selectitem",
    templateUrl:"./selectitem.component.html",
    styleUrls:["./selectitem.component.css"]
})
export class selectitemcomponent{

    List:Item[]=[];
    @Input("item") list:Item;
   amount:number=0;
    ngOnChanges(){
        console.log(this.list);
           this.List.push(this.list);
        
        this.amount=this.amount+this.list.Price;
        
       


    }


    remove(i:Item){
        for(var v=0;v<this.List.length;v++){
            if(this.List[v].Iname==i.Iname){
                this.List.splice(v,1);
            }
        }
        
    }

}