export class Item{
    Iname:string;
    Price:number;

    constructor(Iname:string,Price:number){
        this.Iname=Iname;
        this.Price=Price;
    }
}